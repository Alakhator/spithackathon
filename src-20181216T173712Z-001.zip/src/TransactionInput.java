

public class TransactionInput {

}
