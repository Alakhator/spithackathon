

public class TransactionOutput {

}
