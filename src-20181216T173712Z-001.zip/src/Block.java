import java.util.Date;
public class Block {
	public String hash;
	public String prevhash;
	private String data;
	private long timeStamp;
	private int waitfor0;
	public Block(String data,String prevhash)
	{
		this.data=data;
		this.prevhash=prevhash;
		this.timeStamp=new Date().getTime();
		this.hash=calcHash();
	}
	public String calcHash()
	{
		String calcHash=UtilClass.calcSHA256(prevhash+Long.toString(timeStamp)+Integer.toString(waitfor0)+data);
		return calcHash;
	}
	public void mineblock(int difficulty)
	{
		String target=new String (new char[difficulty]).replace('\0','0');
		System.out.println(target);
		while(!hash.substring(0,difficulty).equals(target))
		{
			waitfor0++;
			hash=calcHash();
			
		}
		System.out.println("runcoin mined:  "+hash);
	}
}
