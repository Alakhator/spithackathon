import java.security.Security;
import java.util.ArrayList;
import java.util.Base64;
import com.google.gson.GsonBuilder;

import apnabitcoin.Wallet;
public class FirstBlockChain {
	public static ArrayList<Block> runcoin=new ArrayList<Block>();
	public static int difficulty=5;
	public static Wallet walletA;
	public static Wallet walletB;
	public static void main(String[] args)
	{
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		
		walletA=new Wallet();
		walletB=new Wallet();
		System.out.println("These are the private and public keys:  ");
		System.out.println(UtilClass.getStringfromKey(walletA.privatekey));
		System.out.println(UtilClass.getStringfromKey(walletA.publickey));
		Transaction firsttrans=new Transaction(walletA.publickey,walletB.publickey,5,null);
		firsttrans.SignIt(walletA.privatekey);
		System.out.println("IS this Signature verified:  ");
		System.out.println(firsttrans.VerifyIt());
		/*runcoin.add(new Block("first block!!","0"));
		System.out.println("Mining 1!!!!!!!!");
		runcoin.get(0).mineblock(difficulty);
		runcoin.add(new Block("second block!!",runcoin.get(runcoin.size()-1).hash));
		System.out.println("Mining 2!!!!!!!!");
		runcoin.get(1).mineblock(difficulty);
		runcoin.add(new Block("third block!!",runcoin.get(runcoin.size()-1).hash));
		System.out.println("Mining 3!!!!!!!!");
		runcoin.get(2).mineblock(difficulty);
		String runcoinJson=new GsonBuilder().setPrettyPrinting().create().toJson(runcoin);
		System.out.println("The runcoin:  ");
		System.out.println(runcoinJson);*/
		
	}
	public static Boolean Validity()
	{
		Block currentBlock;
		Block previousBlock;
		for(int i=1;i<runcoin.size();i++)
		{
			currentBlock=runcoin.get(i);
			previousBlock=runcoin.get(i-1);
			if(!currentBlock.hash.equals(currentBlock.calcHash()))
			{
				System.out.println("Current hashes not equal");
				return false;
			}
			if(!currentBlock.prevhash.equals(previousBlock.hash))
			{
				System.out.println("Previous hashes not equal");
				return false;
			}
			
		}
		return true;
	}
}
