import java.security.*;
import java.util.ArrayList;

public class Transaction {
		public String transactionID;
		public PublicKey sender;
		public PublicKey reciever;
		public float value;
		public byte[] signature;
		public ArrayList<TransactionInput> inputs = new ArrayList<TransactionInput>();
		public ArrayList<TransactionOutput> outputs = new ArrayList<TransactionOutput>();
		private static int sequence =0;
		public Transaction(PublicKey from, PublicKey to, float value, ArrayList<TransactionInput> inputs)
		{
			this.sender = from;
			this.reciever = to;
			this.value = value;
			this.inputs = inputs;
		}
		private String calulateHash() {
			sequence++; 
			return UtilClass.calcSHA256(
					UtilClass.getStringfromKey(sender) +
					UtilClass.getStringfromKey(reciever) +
					Float.toString(value) + sequence
					);
		}
		
		public void SignIt(PrivateKey privatekey)
		{
			String data=UtilClass.getStringfromKey(sender)+UtilClass.getStringfromKey(reciever)+Float.toString(value);
			signature=UtilClass.ECDSASign(privatekey,data);
		}
		
		public boolean VerifyIt()
		{
			String data=UtilClass.getStringfromKey(sender)+UtilClass.getStringfromKey(reciever)+Float.toString(value);
			return UtilClass.verifysign(sender, data, signature);
		}
		
}
