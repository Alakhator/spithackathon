package apnabitcoin;
import java.security.*;
import java.security.spec.ECGenParameterSpec;
public class Wallet {
	public PrivateKey privatekey;
	public PublicKey publickey;
	public Wallet()
	{
		generatekeys();
	}
	public void generatekeys()
	{
		try
		{
			KeyPairGenerator gen=KeyPairGenerator.getInstance("ECDSA","BC");
			SecureRandom random=SecureRandom.getInstance("SHA1PRNG");
			ECGenParameterSpec ecSpec=new ECGenParameterSpec("prime192v1");
			gen.initialize(ecSpec,random);
			KeyPair keypair=gen.generateKeyPair();
			privatekey=keypair.getPrivate();
			publickey=keypair.getPublic();
		}
		catch(Exception e)
		{
			throw new RuntimeException(e);
		}
	}
}
